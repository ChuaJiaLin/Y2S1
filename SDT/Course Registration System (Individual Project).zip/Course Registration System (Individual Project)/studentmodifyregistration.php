<?php
include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=2) { 
    header('Location:login.php');
    exit();
}

include 'headerstudent.php';
include 'dbconnect.php';
$uic=$_SESSION['funame'];

if (isset($_GET['r_tid']) && !empty($_GET['r_tid']) && is_numeric($_GET['r_tid'])){
  $r_tid=intval($_GET['r_tid']);
} 
else{
  die("<div class='container'><h4 style='text-align: center;'>Invalid registration ID.</h4></div>");
}

$sql="SELECT tb_registration.*,
               tb_user.u_name, 
               tb_course.c_name,
               tb_status.s_decs AS status,
               tb_registration.r_course, 
               tb_registration.r_sem
      FROM tb_registration 
      LEFT JOIN tb_user ON tb_registration.r_student=tb_user.u_sno
      LEFT JOIN tb_course ON tb_registration.r_course=tb_course.c_code
      LEFT JOIN tb_status ON tb_registration.r_status=tb_status.s_id
      WHERE r_tid=$r_tid";

$result=mysqli_query($con,$sql);

if (!$result||mysqli_num_rows($result)==0){
    die("<div class='container'><h4 style='text-align: center;'>No registration details found.</h4></div>");
}

$row = mysqli_fetch_assoc($result);

$course_code = $row['r_course'];
$semester = $row['r_sem'];

$sections_query = "SELECT DISTINCT tb_course.c_section 
                   FROM tb_course 
                   LEFT JOIN tb_registration ON tb_course.c_code=tb_registration.r_course 
                   WHERE tb_course.c_code='$course_code' AND tb_course.c_sem='$semester'";

$sections_result = mysqli_query($con, $sections_query);

if (!$sections_result) {
    die("Failed to fetch sections: " . mysqli_error($con));
}

$row=mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $new_section=$_POST['r_section'];

    $update_sql = "UPDATE tb_registration 
                   SET r_section='$new_section'
                   WHERE r_tid='$r_tid'";

    if (!mysqli_query($con,$update_sql)){
        die("Error: " . mysqli_error($con));
    } 
    else{
      header('Location:courseview.php');
    }
}

?>

<style>
  .required{
    color: red;
    font-weight:bold;
  }

</style>

<div class="container">
  <br><br>
  <h1 style="text-align: center;"><b>Modify Registration</b></h1>
    
    <form class="form-container" method="post" action="">
  <fieldset>

    <div class="row">
      <div class="col-sm-10">
    </div>
    <div>
      <label class="form-label mt-4">Registration ID</label>
      <input type="text" class="form-control" value="<?= $row['r_tid']; ?>" disabled>
    </div>
    <div>
      <label class="form-label mt-4">Student ID</label>
      <input type="text" class="form-control" value="<?= $row['r_student']; ?>" disabled>
    </div>
    <div>
      <label class="form-label mt-4">Student Name</label>
      <input type="text" class="form-control" value="<?= $row['u_name']; ?>" disabled>
    </div>
    <div>
      <label class="form-label mt-4">Course Code</label>
      <input type="text" class="form-control" value="<?= $row['r_course']; ?>" disabled>
    </div>
    <div>
      <label class="form-label mt-4">Course Name</label>
      <input type="text" class="form-control" value="<?= $row['c_name']; ?>" disabled>
    </div>
    <div>
    <label class="form-label mt-4">Section <span class="required">*</span></label>
          <select name="r_section" class="form-control" required>
            <option value="<?= $row['r_section']; ?>" selected><?= $row['r_section']; ?></option>
            <?php
            while ($section=mysqli_fetch_assoc($sections_result)) {
                echo "<option value='" . $section['c_section'] . "'>" . $section['c_section'] . "</option>";
            }
            ?>
          </select>
    </div>
    <div>
      <label class="form-label mt-4">Semester</label>
      <input type="text" class="form-control" value="<?= $row['r_sem']; ?>" disabled>
    </div>
    <div>
      <label class="form-label mt-4">Status</label>
      <input type="text" class="form-control" value="<?= $row['status']; ?>" disabled>
      <br>
    </div>
    <div class="d-flex justify-content-center">
        <button type="button" class="btn btn-secondary me-3" onclick="window.location.href='courseview.php'">Back</button>
        <button onclick="return confirmation(event);" class="btn btn-primary">Modify</button>
    </div>
    </form>
    </div>
</div>

<br><br><br><br>

<script>
  function confirmation(event) {
    event.preventDefault(); 
    const fields = document.querySelectorAll("[required]");

    for (let field of fields) {
      if (field.value.trim() === "") {
        Swal.fire({
          icon: 'error',
          title: 'Required field not filled!',
          text: 'Please fill all required fields.',
        });
        event.preventDefault();
        return false;
      }
    }

    event.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: 'Registration will be modified!',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Registration is modified!',
                        showConfirmButton: true
                    }).then(() => {
                        document.querySelector('form').submit();
                    });
                } else {
                    Swal.fire({
                        icon: 'info',
                        title: 'Registration is not modified',
                    }).then(() => {
                        window.location.href='courseview.php';
                    });
                }
            });
        }
</script>





  
</div>
<?php include 'footer.php';?>