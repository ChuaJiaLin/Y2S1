<?php
include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=2) { 
    header('Location:login.php');
    exit();
}

include 'headerstudent.php';
include 'dbconnect.php';
$uic=$_SESSION['funame'];

$sql="SELECT * FROM tb_user
      WHERE u_sno='$uic'";

$result=mysqli_query($con,$sql);

if (!$result||mysqli_num_rows($result)==0){
    die("<div class='container'><h4 style='text-align: center;'>No student details found.</h4></div>");
}

$row=mysqli_fetch_assoc($result);

?>

<div class="container">
  <br><br>
  <h1 style="text-align: center;"><b>Profile</b></h1>

      <div class="card mb-3 col-10 my-5 mx-auto">
      <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
        Student Detail
        <button type="button" class="btn btn-secondary"  onclick="window.location.href='updatestudentprofile.php'">
            Update
        </button> 
      </div>
      <div class="card-body">
        <table class="table table-hover">
          <tbody>
            <tr>
              <td scope="row">Student ID</td>
              <td><?= $row['u_sno']; ?></td>
            </tr>
            <tr>
              <td scope="row">Name</td>
              <td><?= $row['u_name']; ?></td>
            </tr>
            <tr>
              <td scope="row">Email</td>
              <td><?= $row['u_email']; ?></td>
            </tr>
            <tr>
              <td scope="row">Contact</td>
              <td><?= $row['u_contact']; ?></td>
            </tr>
            <tr>
              <td scope="row">State</td>
              <td><?= $row['u_state']; ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    

</div>
<?php include 'footer.php';?>