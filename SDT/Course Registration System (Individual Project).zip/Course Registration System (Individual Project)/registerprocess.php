<?php
//Connect to DB
include('dbconnect.php');
include 'headermain.php';

//Retrieve data from form
$funame = $_POST['funame'];
$fpwd = $_POST['fpwd'];
$fpwd1 = $_POST['fpwd1'];
$femail = $_POST['femail'];
$fname = $_POST['fname'];
$fcontact = $_POST['fcontact'];
$fstate = $_POST['fstate'];
$fusertype = $_POST['fusertype'];

if ($fpwd !== $fpwd1) {
    echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Passwords do not match!',
                text: 'Please try again.'
            }).then(() => {
                window.location.href='register.php';
            });
          </script>";
    exit();
} else {
    $hashed_password=md5($fpwd);
    $sql="INSERT INTO tb_user (u_sno,u_pwd,u_email,u_name,u_contact,u_state,u_registration,u_type)
          VALUES ('$funame','$hashed_password','$femail','$fname','$fcontact','$fstate', CURRENT_TIMESTAMP(),'$fusertype')";

    mysqli_query($con, $sql);

    echo "<script>
            Swal.fire({
                icon: 'success',
                title: 'Registration Successful!',
                text: 'You can now log in.',
                showConfirmButton: true
            }).then(() => {
                window.location.href='login.php';
            });
          </script>";
}

//Close connection
mysqli_close($con);

?>