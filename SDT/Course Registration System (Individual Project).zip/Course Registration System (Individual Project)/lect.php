<?php 

include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type'] != 1) { 
    header('Location: login.php');
    exit();
}

include 'headerlect.php';
include 'dbconnect.php';

?>

<div class="container">
  <br><br>
  <div class="jumbotron">
  <h1 class="display-3">Hi, Lecturer!</h1>
  <p class="lead">Welcome to Course Registration System!</p>
  <p class="lead">You can access shortcuts below to access your function.</p>
  <hr class="my-4">

  <div class="row mt-5">
    <div class="col-md-4">
      <a href="lectcourselist.php" class="btn btn-outline-primary w-100">Courses Assigned</a>
      <a href="modifypassword.php" class="btn btn-outline-primary w-100">Modify Password</a>
    </div>
  </div>
</div>

        
</div>
</div>

<?php include 'footer.php';?>