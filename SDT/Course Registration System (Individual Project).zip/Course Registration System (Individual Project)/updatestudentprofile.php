<?php 
include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=2) { 
    header('Location:login.php');
    exit();
}

include 'headerstudent.php';
include 'dbconnect.php';
$uic=$_SESSION['funame'];

function callResult($con, $uic) {

$sql = "SELECT * FROM tb_user
        WHERE tb_user.u_sno='$uic'";

$result = mysqli_query($con, $sql);

if (!$result) {
    die("Query failed: ".mysqli_error($con));
}

$row = mysqli_fetch_assoc($result);

return $row;

}

$row = callResult($con, $uic);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $contact=$_POST['contact'];
    $state=$_POST['state'];
    
if(!empty($_POST)) {

  $sql = "UPDATE tb_user
          SET 
            u_name='$name', 
            u_email='$email',
            u_contact='$contact',
            u_state='$state'
          WHERE u_sno='$uic'";

    if(!mysqli_query($con, $sql)) {
      die("Update failed!" . mysqli_error($con));
    }
    else{
      header('Location:studentprofile.php');
    }
}

}

?>


  <style>
    body {
      background-color: #f9f9f9;
    }

    .fixed-table-container{
      position: fixed;
      top: 60px;
      width:100%;
      background-color: White;
      z-index:1;
    }

    .form-container{
      max-width: 700px;
      margin: 0 auto;
    }

    .required {
      color: red;
      font-weight: bold;
    }

  </style>
</head>
<body>
  
  <div class="my-3"></div>

    <h2 style="text-align: center;">Student Personal Information</h2>

  <div class="my-3"></div>

<form class="form-container" method="post" action="">
  <fieldset>

    <div class="row">
      <div class="col-sm-10">
    </div>
    <div>
      <label class="form-label mt-4">Name <span class="required">*</span></label>
      <input type="text" class="form-control" name="name" value="<?= $row['u_name']; ?>" required>
    </div>
    <div>
      <fieldset>
        <label class="form-label mt-4">Email </label>
        <input class="form-control" type="text" name="email" value="<?= $row['u_email']; ?>"  required>
      </fieldset>
    </div>
    <div>
      <label class="form-label mt-4">Contact <span class="required">*</span></label>
      <input type="text" class="form-control" name="contact" value="<?= $row['u_contact']; ?>" required>
    </div>
  </div>
    <div>
      <label class="form-label mt-4">Negeri <span class="required">*</span></label>
      <select class="form-select" name="state" placeholder="<?= $row['state']; ?>" required>
        <option>Johor</option>
        <option>Kedah</option>
        <option>Kelantan</option>
        <option>Melaka</option>
        <option>Negeri Sembilan</option>
        <option>Pahang</option>
        <option>Pulau Pinang</option>
        <option>Sabah</option>
        <option>Sarawak</option>
        <option>Selangor</option>
        <option>Terengganu</option>
        <option>WP Kuala Lumpur</option>
        <option>WP Labuan</option>
        <option>WP Putrajaya</option>
        <option>Perak</option>
        <option>Perlis</option>
      </select>
    </div>
    <div class="d-flex justify-content-center">
      <button type="button" class="btn btn-secondary me-3 mt-4" onclick="window.location.href='studentprofile.php'">Back</button>
      <button onclick="return confirmation(event);" class="btn btn-primary mt-4">Save</button>
    </div>
  </fieldset>
</form>
  

<script>
  function confirmation(event) {
    const fields = document.querySelectorAll("[required]");

    for (let field of fields) {
      if (field.value.trim() === "") {
        Swal.fire({
          icon: 'error',
          title: 'Required field not filled!',
          text: 'Please fill all required fields.',
        });
        event.preventDefault();
        return false;
      }
    }

    event.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: 'Your personal information will be updated.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Your personal information is updated!',
                        showConfirmButton: true
                    }).then(() => {
                        document.querySelector('form').submit();
                    });
                } else {
                    Swal.fire({
                        icon: 'info',
                        title: 'Your personal information is not updated.',
                    }).then(() => {
                        window.location.href='studentprofile.php';
                    });
                }
            });
        }
</script>


</body>
</html>


<div class="my-5"></div><br>
  
</body>
</html>

<?php include 'footer.php';?>
