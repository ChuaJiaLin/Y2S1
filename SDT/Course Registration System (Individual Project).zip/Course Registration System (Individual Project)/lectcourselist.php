<?php
include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=1) {
    header('Location:login.php');
    exit();
}

include 'headerlect.php';
include 'dbconnect.php';
$uic=$_SESSION['funame'];

$selected_sem=isset($_GET['sem'])?$_GET['sem']:'all';
$sem_query="SELECT DISTINCT c_sem
            FROM tb_course
            WHERE c_lec='$uic'
            ORDER BY c_sem";
$sem_result=mysqli_query($con,$sem_query);

$sql="SELECT * FROM tb_course
      LEFT JOIN tb_user ON tb_course.c_lec = tb_user.u_sno
      WHERE c_lec='$uic'";

if($selected_sem!='all'){
  $sql .="AND c_sem='$selected_sem'";
}

$result=mysqli_query($con,$sql);
?>

<style>
  table thead th{
    text-align: center;
    background-color: #f1f1f1;
  }

  table tbody td{
    text-align: center;
  }
  
</style>

<div class="container">
  <br><br>
  <h1 style="text-align: center;"><b>Courses Assigned</b></h1><br>
  <form method="GET" class="form-inline">
    <label for="sem">Select Semester:</label>
    <select name="sem" id="sem" class="form-control">
      <option value="all" <?php echo $selected_sem==='all' ? 'selected':''; ?>>All Semesters</option>
  
        <?php
          while ($sem_row=mysqli_fetch_array($sem_result)){
            $sem=$sem_row['c_sem'];
            echo "<option value='$sem'".($selected_sem==$sem ? ' selected':'').">$sem</option>";
          }
        ?>
    </select>
    <br>
    <div class="d-flex justify-content-center">
      <button type="submit" class="btn btn-primary">Filter</button>
    </div>
  </form>

<br><br>
<table class="table table-hover">
  <thead>
    
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Semester</th>
      <th scope="col">Course</th>
      <th scope="col">Course Name</th>
      <th scope="col">View Course Detail</th>
      <th scope="col">View Student List</th>
    </tr>
  </thead>
  <tbody>

    <?php
    while($row=mysqli_fetch_array($result)){
      echo"<tr>";
      echo"<td>".$row['c_id']."</td>";
      echo"<td>".$row['c_sem']."</td>";
      echo"<td>".$row['c_code']."</td>";
      echo"<td>".$row['c_name']."</td>";
      echo"<td>";
      echo "<a href='coursedetail.php?c_id=" . $row['c_id'] . "'><button type='submit' class='btn btn-info'>Course Detail</button></a>";
      echo "<td>";
      echo "<a href='studentlist.php?c_id=" . $row['c_id'] . "'><button type='submit' class='btn btn-info'>Student List</button></a>";
      echo"</tr>";
    }
?>

   
    
  </tbody>
</table>
<br><br><br><br>





  
</div>
<?php include 'footer.php';?>