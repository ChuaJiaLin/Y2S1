<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

if ($_SESSION['u_type']!=3) { 
    header('Location:login.php');
    exit();
}

include 'headeradmin.php';
include 'dbconnect.php';

$records_per_page=10;

$current_page=isset($_GET['page']) ? (int)$_GET['page']:1;

$offset=($current_page-1)*$records_per_page;

$count_sql="SELECT COUNT(*) AS total 
            FROM tb_course";

$count_result=mysqli_query($con,$count_sql);
$total_records=mysqli_fetch_assoc($count_result)['total'];

$total_pages=ceil($total_records/$records_per_page);

$search_code=isset($_GET['search_code']) ? $_GET['search_code'] : '';

$sql = "SELECT * FROM tb_course 
        LEFT JOIN tb_user ON tb_course.c_lec=tb_user.u_sno
        LIMIT $records_per_page OFFSET $offset";

if (!empty($search_code)){
    $sql.=" WHERE c_code LIKE '%$search_code%'";
}

$result=mysqli_query($con, $sql);

if (isset($_GET['delete_id'])) {
    $delete_id=$_GET['delete_id'];
    $delete_query="DELETE FROM tb_course 
                   WHERE c_id='$delete_id'";
    mysqli_query($con,$delete_query);
    header('Location: admincourselist.php');
    exit();
}
?>

<style>
  table thead th{
      text-align: center;
      background-color: #f1f1f1;
  }

  table tbody td{
      text-align: center;
  }
</style>

<div class="container">
    <br><br>
    <h1 style="text-align: center;"><b>Manage Courses</b></h1><br>

    <form method="GET" class="form-inline">
        <label for="search_code">Search Course Code:</label>
        <input type="text" name="search_code" id="search_code" class="form-control" value="<?php echo $search_code; ?>" placeholder="Enter course code">
        <br>
        <div class="d-flex justify-content-center">
          <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>

    <br>

    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Course Code</th>
          <th scope="col">Course Name</th>
          <th scope="col">Section</th>
          <th scope="col">Semester</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
            <?php
            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                echo "<td>" . $row['c_id'] . "</td>";
                echo "<td>" . $row['c_code'] . "</td>";
                echo "<td>" . $row['c_name'] . "</td>";
                echo "<td>" . $row['c_section'] . "</td>";
                echo "<td>" . $row['c_sem'] . "</td>";
                echo "<td>";
                echo "<a href='admincoursedetail.php?c_id=" . $row['c_id'] . "'><button class='btn btn-info me-3'>Details</button></a> ";
                echo "<button class='btn btn-danger me-3' onclick=\"delete_course(" . $row['c_id'] . ")\">Delete</button>";
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<nav>
  <ul class="pagination justify-content-center">
    <?php if ($current_page>1): ?>
    <li class="page-item">
      <a class="page-link" href="?page=<?= $current_page-1; ?>">&laquo;</a>
    </li>
    <?php endif; ?>

    <?php for ($i=1;$i<=$total_pages;$i++): ?>
    <li class="page-item <?= ($i==$current_page) ? 'active' : ''; ?>">
      <a class="page-link" href="?page=<?= $i; ?>"><?= $i; ?></a>
    </li>
    <?php endfor; ?>

    <?php if ($current_page<$total_pages): ?>
    <li class="page-item">
      <a class="page-link" href="?page=<?= $current_page+1; ?>">&raquo;</a>
    </li>
    <?php endif; ?>
  </ul>
</nav>

<br><br><br><br>

<script>
  function delete_course(delete_id){
    Swal.fire({
      title: 'Are you sure?',
      text: 'This course will be deleted and all student registered will be removed.',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No'
    }).then((result) => {
      if (result.isConfirmed){
        Swal.fire({
          icon: 'success',
          title: 'Course is deleted and all student registered are removed!',
          showConfirmButton: true
        }).then(() => {
          window.location.href = `admincourselist.php?delete_id=${delete_id}`;
        });
      } 
      else {
        Swal.fire({
          icon: 'info',
          title: 'No course is deleted!',
        }).then(() => {
          window.location.href='admincourselist.php';
        });
      }
    });
  }
</script>
<?php include 'footer.php'; ?>
