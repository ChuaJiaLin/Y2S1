<?php
include('crssession.php');
if (!session_id()) {
    session_start();
}

if ($_SESSION['u_type']!=1) {
    header('Location:login.php');
    exit();
}

include 'headerlect.php';
include 'dbconnect.php';

if (!isset($_SESSION['funame'])) {
    header("Location: login.php");
    exit();
}

$uic = $_SESSION['funame'];

if (isset($_GET['r_student']) && !empty($_GET['r_student']) && isset($_GET['c_id']) && is_numeric($_GET['c_id'])){
    $r_student=mysqli_real_escape_string($con, $_GET['r_student']);
    $c_id=intval($_GET['c_id']);
} 
else{
  die("<div class='container'><h4 style='text-align: center;'>Invalid student ID.</h4></div>");
}

$sql = "SELECT * FROM tb_user
        LEFT JOIN tb_registration ON tb_registration.r_student=tb_user.u_sno
        WHERE tb_user.u_sno='$r_student'";

$result=mysqli_query($con, $sql);

if (!$result || mysqli_num_rows($result)==0){
  die("<div class='container'><h4 style='text-align: center;'>No student details found.</h4></div>");
}

$row=mysqli_fetch_assoc($result);
?>

<div class="container">
    <br><br>
    <h1 style="text-align: center;"><b>Student Details</b></h1>

    <div class="card mb-3 col-10 my-5 mx-auto">
        <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
            Student Details
            <button type="button" class="btn btn-secondary" onclick="window.location.href='studentlist.php?c_id=<?php echo $c_id; ?>'">Back</button>
        </div>
        <div class="card-body">
            <table class="table table-hover">
                <tbody>
                    <tr>
                        <td scope="row">ID</td>
                        <td><?= htmlspecialchars($row['u_sno']); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Name</td>
                        <td><?= htmlspecialchars($row['u_name']); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Email</td>
                        <td><?= htmlspecialchars($row['u_email']); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">Contact</td>
                        <td><?= htmlspecialchars($row['u_contact']); ?></td>
                    </tr>
                    <tr>
                        <td scope="row">State</td>
                        <td><?= htmlspecialchars($row['u_state']); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <br><br><br><br>
</div>

<?php include 'footer.php'; ?>
