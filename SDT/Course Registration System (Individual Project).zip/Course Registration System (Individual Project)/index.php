<?php include 'headermain.php';?>
<div class="container">
  <br><br>
  <div class="jumbotron">
  <h1 class="display-3">Hello!</h1>
  <p class="lead">Welcome to Course Registration System.</p>
  <hr class="my-4">
  <p>You can access shortcuts below.</p>
  <p class="lead">
    <a class="btn btn-primary btn-lg me-3" href="login.php" role="button">Login</a>
    <a class="btn btn-primary btn-lg" href="register.php" role="button">Register</a>
  </p>
</div>
</div>
<?php include 'footer.php';?>