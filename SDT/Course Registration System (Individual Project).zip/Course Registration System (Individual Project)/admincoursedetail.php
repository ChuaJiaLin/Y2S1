<?php
include('crssession.php');
if(!session_id())
{
  session_start();
}

if ($_SESSION['u_type']!=3) { 
    header('Location: login.php');
    exit();
}

include 'headeradmin.php';
include 'dbconnect.php';
$uic=$_SESSION['funame'];

if (isset($_GET['c_id']) && !empty($_GET['c_id']) && is_numeric($_GET['c_id'])){
  $c_id=intval($_GET['c_id']);
} 
else{
  die("<div class='container'><h4 style='text-align: center;'>Invalid course ID.</h4></div>");
}

$sql="SELECT * FROM tb_course
      LEFT JOIN tb_user ON tb_course.c_lec = tb_user.u_sno
      WHERE c_id=$c_id";

$result=mysqli_query($con,$sql);

if (!$result||mysqli_num_rows($result)==0){
    die("<div class='container'><h4 style='text-align: center;'>No course details found.</h4></div>");
}

$row=mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $new_code=$_POST['c_code'];
    $new_name=$_POST['c_name'];
    $new_sem=$_POST['c_sem'];
    $new_section=$_POST['c_section'];
    $new_capacity=$_POST['c_studNum'];
    $new_lec=$_POST['c_lec'];
    $new_credit=substr($_POST['c_code'],-1);

    $update_sql = "UPDATE tb_course 
                   SET c_code='$new_code', c_name='$new_name', c_sem='$new_sem', c_section='$new_section',c_studNum='$new_capacity',c_lec='$new_lec',c_credit='$new_credit' 
                   WHERE c_id='$c_id'";

    if (!mysqli_query($con,$update_sql)){
        die("Error: " . mysqli_error($con));
    } 
    else{
      header('Location:admincourselist.php');
    }
}

?>

<style>
  .required{
    color: red;
    font-weight:bold;
  }

</style>

<div class="container">
  <br><br>
  <h1 style="text-align: center;"><b>Course Detail</b></h1>

      <div class="card mb-3 col-10 my-5 mx-auto">
      <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
        Course Detail
        <button type="button" class="btn btn-secondary"  onclick="window.location.href='admincourselist.php'">
            Back
        </button> 
      </div>
      <div class="card-body">
        <table class="table table-hover">
          <tbody>
            <tr>
              <td scope="row">ID</td>
              <td><?= $row['c_id']; ?></td>
            </tr>
            <tr>
              <td scope="row">Code</td>
              <td><?= $row['c_code']; ?></td>
            </tr>
            <tr>
              <td scope="row">Name</td>
              <td><?= $row['c_name']; ?></td>
            </tr>
            <tr>
              <td scope="row">Credit</td>
              <td><?= $row['c_credit']; ?></td>
            </tr>
            <tr>
              <td scope="row">Semester</td>
              <td><?= $row['c_sem']; ?></td>
            </tr>
            <tr>
              <td scope="row">Section</td>
              <td><?= $row['c_section']; ?></td>
            </tr>
            <tr>
              <td scope="row">Lecturer ID</td>
              <td><?= $row['c_lec']; ?></td>
            </tr>
            <tr>
              <td scope="row">Lecturer Name</td>
              <td><?= $row['u_name']; ?></td>
            </tr>
            <tr>
              <td scope="row">Number of Student</td>
              <td><?= $row['c_studNum']; ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card mb-3 col-10 my-5 mx-auto">
    <div class="card-header text-white bg-primary d-flex justify-content-between align-items-center">
        Modify Course Detail
    </div>
    <div class="card-body">
        <form method="post">
            <div class="form-group">
                <label for="c_code">Course Code <span class="required">*</span></label>
                <input type="text" class="form-control" name="c_code" id="c_code" value="<?= $row['c_code']; ?>" required>
            </div>
            <br>
            <div class="form-group">
                <label for="c_name">Course Name <span class="required">*</span></label>
                <input type="text" class="form-control" name="c_name" id="c_name" value="<?= $row['c_name']; ?>" required>
            </div>
            <br>
            <div class="form-group">
                <label for="c_sem">Semester <span class="required">*</span></label>
                <select class="form-control" name="c_sem" id="c_sem" required>
                    <option value="2024/2025-1" <?= $row['c_sem'] == '2024/2025-1' ? 'selected' : ''; ?>>2024/2025-1</option>
                    <option value="2024/2025-2" <?= $row['c_sem'] == '2024/2025-2' ? 'selected' : ''; ?>>2024/2025-2</option>
                    <option value="2024/2025-3" <?= $row['c_sem'] == '2024/2025-3' ? 'selected' : ''; ?>>2024/2025-3</option>
                </select>
            </div>
            <br>
            <div class="form-group">
                <label for="c_section">Section <span class="required">*</span></label>
                <input type="text" class="form-control" name="c_section" id="c_section" value="<?= $row['c_section']; ?>" required>
            </div>
            <br>
            <div class="form-group">
                <label for="c_studNum">Number of Students <span class="required">*</span></label>
                <input type="number" class="form-control" name="c_studNum" id="c_studNum" value="<?= $row['c_studNum']; ?>" required>
            </div>
            <br>
            <div class="form-group">
                <label for="c_lec">Lecturer <span class="required">*</span></label>
                <select class="form-control" name="c_lec" id="c_lec" required>
                    <?php
                    $lecturers_query = "SELECT u_sno, u_name FROM tb_user WHERE u_type='1'";
                    $lecturers_result = mysqli_query($con, $lecturers_query);
                    while ($lecturer = mysqli_fetch_assoc($lecturers_result)) {
                        $selected = $lecturer['u_sno'] == $row['c_lec'] ? 'selected' : '';
                        echo "<option value='" . $lecturer['u_sno'] . "' $selected>" . $lecturer['u_name'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <br>
            <div class="d-flex justify-content-center">
                <button type="button" class="btn btn-secondary me-2" onclick="window.location.href='admincourselist.php'">Back</button>
                <button onclick="return confirmation(event);" class="btn btn-primary">Update Course</button>
            </div>
        </form>
    </div>
</div>

<br><br><br><br>

<script>
  function confirmation(event) {
    event.preventDefault(); 
    const fields = document.querySelectorAll("[required]");

    for (let field of fields) {
      if (field.value.trim() === "") {
        Swal.fire({
          icon: 'error',
          title: 'Required field not filled!',
          text: 'Please fill all required fields.',
        });
        event.preventDefault();
        return false;
      }
    }

    event.preventDefault();

            Swal.fire({
                title: 'Are you sure?',
                text: 'Course detail will be updated!',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Course detail is updated!',
                        showConfirmButton: true
                    }).then(() => {
                        document.querySelector('form').submit();
                    });
                } else {
                    Swal.fire({
                        icon: 'info',
                        title: 'Course detail is not updated',
                    }).then(() => {
                        window.location.href='admincourselist.php';
                    });
                }
            });
        }
</script>





  
</div>
<?php include 'footer.php';?>